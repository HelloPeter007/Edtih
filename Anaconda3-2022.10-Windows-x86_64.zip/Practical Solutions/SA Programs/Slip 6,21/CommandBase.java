package CommandPattern;

public interface CommandBase {
	
		void execute();
		void undo();
		
}
