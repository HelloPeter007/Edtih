var MongoClient=require('mongodb').MongoClient;
var url="mongodb://0.0.0.0:27017/MyD";
MongoClient.connect(url,function(err,db){
if(err) throw err;
var dbase=db.db("MyD");
dbase.createCollection("employess",function(err,res)
{
if(err) throw err;
console.log("Collection is created!");
db.close();
});
});