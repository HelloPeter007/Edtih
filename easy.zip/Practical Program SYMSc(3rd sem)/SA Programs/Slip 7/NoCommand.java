package CommandPattern;

public class NoCommand implements Command{

	@Override
	public void execute() {}
	@Override
	public void undo() {}
	
}
